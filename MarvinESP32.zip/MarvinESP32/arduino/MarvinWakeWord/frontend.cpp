#include "frontend.h"
#include <cmath>
#include <algorithm>

namespace marvin {
namespace {
constexpr float kPi = 3.14159265358979323846f;
float mel(float hz) { return 1127.0f * std::log(1.0f + hz / 700.0f); }
// NumPy / TensorFlow round uses ties-to-even (not C++ round's ties-away).
int roundEven(float x) {
  const float lower = std::floor(x);
  int q = static_cast<int>(lower);
  const float fraction = x - lower;
  if (fraction > 0.5f || (fraction == 0.5f && (q % 2 != 0))) ++q;
  return q;
}
}
void Frontend::begin() {
  for (int n = 0; n < 400; ++n)
    window_[n] = 0.5f - 0.5f * std::cos(2.0f * kPi * n / 400.0f);
  for (int n = 0; n < 256; ++n) {
    twiddleRe_[n] = std::cos(-2.0f * kPi * n / 512.0f);
    twiddleIm_[n] = std::sin(-2.0f * kPi * n / 512.0f);
  }
  float edges[26];
  const float low = mel(80.0f), high = mel(7600.0f);
  for (int b = 0; b < 26; ++b) edges[b] = low + (high - low) * b / 25.0f;
  for (int k = 0; k <= 256; ++k) {
    bands_[k][0] = bands_[k][1] = -1;
    weights_[k][0] = weights_[k][1] = 0;
    if (k == 0) continue;  // TensorFlow zeroes the DC bin.
    const float m = mel(k * (16000.0f / 512.0f));
    int slot = 0;
    for (int b = 0; b < 24; ++b) {
      const float rising = (m - edges[b]) / (edges[b + 1] - edges[b]);
      const float falling = (edges[b + 2] - m) / (edges[b + 2] - edges[b + 1]);
      const float w = std::max(0.0f, std::min(rising, falling));
      if (w > 0.0f && slot < 2) {
        bands_[k][slot] = b;
        weights_[k][slot++] = w;
      }
    }
  }
}
void Frontend::fft() {
  for (unsigned i = 1, j = 0; i < 512; ++i) {
    unsigned bit = 256;
    for (; j & bit; bit >>= 1) j ^= bit;
    j ^= bit;
    if (i < j) { std::swap(re_[i], re_[j]); std::swap(im_[i], im_[j]); }
  }
  for (int length = 2; length <= 512; length <<= 1) {
    const int half = length / 2, stride = 512 / length;
    for (int start = 0; start < 512; start += length) {
      for (int j = 0; j < half; ++j) {
        const int a = start + j, b = a + half, t = j * stride;
        const float r = re_[b] * twiddleRe_[t] - im_[b] * twiddleIm_[t];
        const float i = re_[b] * twiddleIm_[t] + im_[b] * twiddleRe_[t];
        re_[b] = re_[a] - r; im_[b] = im_[a] - i;
        re_[a] += r; im_[a] += i;
      }
    }
  }
}
void Frontend::compute(float* audio, int8_t* output, float* features) {
  // Float32 reduction, like the training tensor. Eight partial sums limit
  // accumulation drift without software double arithmetic on the ESP32.
  float sums[8] = {};
  for (int n = 0; n < kSamples; n += 8)
    for (int j = 0; j < 8; ++j) sums[j] += audio[n + j];
  const float sum = ((sums[0] + sums[1]) + (sums[2] + sums[3])) +
                    ((sums[4] + sums[5]) + (sums[6] + sums[7]));
  const float mean = sum / static_cast<float>(kSamples);
  float previous = audio[0] - mean;
  audio[0] = previous;  // x[0] retained; no preceding sample from previous window.
  for (int n = 1; n < kSamples; ++n) {
    const float centered = audio[n] - mean;
    audio[n] = centered - 0.97f * previous;
    previous = centered;
  }
  for (int frame = 0; frame < kFrames; ++frame) {
    for (int n = 0; n < 512; ++n) {
      re_[n] = n < 400 ? audio[frame * 160 + n] * window_[n] : 0.0f;
      im_[n] = 0.0f;
    }
    fft(); // Unnormalized forward FFT, no one-sided power doubling.
    float energies[kMels] = {};
    for (int k = 0; k <= 256; ++k) {
      const float power = re_[k] * re_[k] + im_[k] * im_[k];
      for (int s = 0; s < 2; ++s)
        if (bands_[k][s] >= 0) energies[bands_[k][s]] += power * weights_[k][s];
    }
    for (int b = 0; b < kMels; ++b) {
      const float logmel = std::max(-12.0f, std::min(4.0f, std::log(energies[b] + 1e-6f)));
      const float feature = (logmel + 4.0f) / 8.0f;
      const int index = frame * kMels + b;
      if (features) features[index] = feature;
      output[index] = static_cast<int8_t>(std::max(-128, std::min(127,
          roundEven(feature / kInputScale + kInputZero))));
    }
  }
}
}
