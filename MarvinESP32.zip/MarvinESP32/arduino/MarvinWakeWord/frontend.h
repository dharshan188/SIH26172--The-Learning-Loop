#pragma once
#include <cstddef>
#include <cstdint>

namespace marvin {
constexpr int kSamples = 16000, kFrames = 98, kMels = 24;
constexpr float kInputScale = 0.007843137718737125f;
constexpr int kInputZero = -1;
// Workspace is static in the sketch; no heap allocations, no full spectrogram.
class Frontend {
 public:
  void begin();
  // Mutates audio: DC removal and pre-emphasis, then writes frame-major INT8.
  // Optional float output is useful for host parity tests, omitted on-device.
  void compute(float* audio, int8_t* output, float* features = nullptr);
 private:
  void fft();
  float window_[400], twiddleRe_[256], twiddleIm_[256];
  float re_[512], im_[512];
  // Each FFT bin contributes to at most two adjacent Mel triangles.
  float weights_[257][2];
  int8_t bands_[257][2];
};
}
