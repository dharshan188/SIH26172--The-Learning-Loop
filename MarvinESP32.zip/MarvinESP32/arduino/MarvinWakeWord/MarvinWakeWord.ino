#include <Arduino.h>
#include <Chirale_TensorFlowLite.h>
#include <tensorflow/lite/micro/micro_interpreter.h>
#include <tensorflow/lite/micro/micro_mutable_op_resolver.h>
#include <tensorflow/lite/schema/schema_generated.h>
#include <driver/i2s_std.h>
#include <esp_heap_caps.h>
#include <esp_timer.h>
#include <freertos/FreeRTOS.h>
#include <freertos/queue.h>
#include <freertos/task.h>
#include <cmath>
#include "frontend.h"
#include "marvin_model_data.h"

// Fixed-size buffers; no PSRAM, Wi-Fi, Bluetooth, String, or per-cycle allocation.
constexpr size_t kArenaBytes = 32 * 1024;
constexpr float kThreshold = 0.365f;
constexpr uint32_t kHeapCaps = MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT;
alignas(16) static uint8_t arena[kArenaBytes];
// Allocate the two large buffers once at startup: original ESP32 cannot put
// all 128 KB plus TFLM/DSP/system globals into its limited static DRAM region.
static float* audio[2] = {}; // Preserve all 24 microphone bits.
static marvin::Frontend frontend;
static tflite::MicroInterpreter* interpreter;
static TfLiteTensor* input;
static TfLiteTensor* output;
static i2s_chan_handle_t rx;

struct AudioWindow {
  int index;
  uint32_t sequence;
  int64_t startUs;
  int64_t endUs;
  uint32_t dmaOverflows;
  uint32_t skippedWindows;
  float peak;
};
static StaticQueue_t freeQueueState, readyQueueState;
static uint8_t freeQueueStorage[2 * sizeof(int)];
static uint8_t readyQueueStorage[2 * sizeof(AudioWindow)];
static QueueHandle_t freeQueue, readyQueue;
static StaticTask_t captureTaskState;
// ESP-IDF static-task stack depth is BYTES, unlike vanilla FreeRTOS.
static StackType_t captureStack[4096 / sizeof(StackType_t)];
static uint32_t dmaOverflows = 0;
static portMUX_TYPE overflowMux = portMUX_INITIALIZER_UNLOCKED;
static uint32_t readOverflows() {
  portENTER_CRITICAL(&overflowMux);
  const uint32_t count = dmaOverflows;
  portEXIT_CRITICAL(&overflowMux);
  return count;
}
static size_t setupFreeHeap;
extern "C" { extern char _data_start, _data_end, _bss_start, _bss_end; }

static void fatal(const char* message) {
  Serial.printf("\nFATAL: %s\n", message);
  if (rx) i2s_channel_disable(rx);
  while (true) delay(1000);
}
static void checkEsp(esp_err_t err, const char* what) {
  if (err != ESP_OK) {
    Serial.printf("%s: %s\n", what, esp_err_to_name(err));
    fatal("I2S initialization failed");
  }
}
static bool IRAM_ATTR onOverflow(i2s_chan_handle_t, i2s_event_data_t*, void*) {
  portENTER_CRITICAL_ISR(&overflowMux);
  ++dmaOverflows;
  portEXIT_CRITICAL_ISR(&overflowMux);
  return false;
}
static void captureTask(void*) {
  // Stereo DMA, explicitly select right slot. This avoids original ESP32
  // mono FIFO ordering quirks and supplies the INMP441 its 64 BCLK/frame.
  int32_t stereo[256 * 2];
  uint32_t sequence = 0, skipped = 0;
  // Discard 100 ms startup audio, letting the microphone stabilize.
  size_t warmup = 1600;
  while (warmup) {
    size_t bytes = 0;
    const size_t frames = warmup < 256 ? warmup : 256;
    checkEsp(i2s_channel_read(rx, stereo, frames * 8, &bytes, 2000), "I2S warmup");
    if (bytes == 0 || bytes % 8) fatal("Invalid I2S warmup read");
    warmup -= bytes / 8;
  }
  uint32_t previousOverflows = readOverflows();
  for (;;) {
    int index = -1;
    xQueueReceive(freeQueue, &index, 0);
    AudioWindow window{};
    window.index = index;
    window.sequence = ++sequence;
    window.startUs = esp_timer_get_time();
    size_t offset = 0;
    while (offset < marvin::kSamples) {
      const size_t remaining = marvin::kSamples - offset;
      const size_t frames = remaining < 256 ? remaining : 256;
      size_t bytes = 0;
      checkEsp(i2s_channel_read(rx, stereo, frames * 8, &bytes, 2000), "I2S read");
      if (!bytes || bytes % 8) fatal("I2S returned incomplete stereo frame");
      const size_t got = bytes / 8;
      for (size_t n = 0; n < got; ++n) {
        // Signed 24-bit microphone sample is left aligned in signed 32-bit slot.
        // Remove the undefined low 8 bits without reducing to 16-bit PCM.
        const int32_t pcm24 = stereo[2 * n + 1] >> 8;
        const float value = static_cast<float>(pcm24) / 8388608.0f;
        if (index >= 0) audio[index][offset + n] = value;
        window.peak = fmaxf(window.peak, fabsf(value));
      }
      offset += got;
    }
    window.endUs = esp_timer_get_time();
    window.dmaOverflows = readOverflows();
    const bool lostSamples = window.dmaOverflows != previousOverflows;
    previousOverflows = window.dmaOverflows;
    if (index < 0) { ++skipped; continue; }
    // A DMA overflow implies lost samples: never infer on a corrupted window.
    if (lostSamples) {
      ++skipped;
      xQueueSend(freeQueue, &index, portMAX_DELAY);
      continue;
    }
    window.skippedWindows = skipped;
    if (xQueueSend(readyQueue, &window, 0) != pdTRUE) {
      ++skipped;
      xQueueSend(freeQueue, &index, portMAX_DELAY);
    }
  }
}
static void setupI2S() {
  i2s_chan_config_t channel = I2S_CHANNEL_DEFAULT_CONFIG(I2S_NUM_0, I2S_ROLE_MASTER);
  channel.dma_desc_num = 4;
  channel.dma_frame_num = 256; // 8192 bytes stereo DMA, 64 ms buffering.
  checkEsp(i2s_new_channel(&channel, nullptr, &rx), "i2s_new_channel");
  i2s_std_config_t config = {};
  config.clk_cfg = I2S_STD_CLK_DEFAULT_CONFIG(16000);
  config.slot_cfg = I2S_STD_PHILIPS_SLOT_DEFAULT_CONFIG(I2S_DATA_BIT_WIDTH_32BIT, I2S_SLOT_MODE_STEREO);
  config.slot_cfg.slot_mask = I2S_STD_SLOT_BOTH;
  config.gpio_cfg.mclk = I2S_GPIO_UNUSED;
  config.gpio_cfg.bclk = GPIO_NUM_14;
  config.gpio_cfg.ws = GPIO_NUM_15;
  config.gpio_cfg.dout = I2S_GPIO_UNUSED;
  config.gpio_cfg.din = GPIO_NUM_32;
  checkEsp(i2s_channel_init_std_mode(rx, &config), "i2s_channel_init_std_mode");
  i2s_event_callbacks_t callbacks = {};
  callbacks.on_recv_q_ovf = onOverflow;
  checkEsp(i2s_channel_register_event_callback(rx, &callbacks, nullptr), "I2S callbacks");
  checkEsp(i2s_channel_enable(rx), "i2s_channel_enable");
}
static size_t staticRamBytes() {
  return (reinterpret_cast<uintptr_t>(&_data_end) - reinterpret_cast<uintptr_t>(&_data_start)) +
         (reinterpret_cast<uintptr_t>(&_bss_end) - reinterpret_cast<uintptr_t>(&_bss_start));
}
static void printRam() {
  const size_t free = heap_caps_get_free_size(kHeapCaps);
  const size_t heapTotal = heap_caps_get_total_size(kHeapCaps);
  const size_t heapUsed = heapTotal - free;
  Serial.printf("RAM: free_heap=%u, minimum_free_heap=%u, largest_free_block=%u bytes\n",
                unsigned(free), unsigned(heap_caps_get_minimum_free_size(kHeapCaps)),
                unsigned(heap_caps_get_largest_free_block(kHeapCaps)));
  Serial.printf("RAM: static_data_bss=%u, allocated_heap=%u, approximate_runtime_RAM=%u bytes\n",
                unsigned(staticRamBytes()), unsigned(heapUsed), unsigned(staticRamBytes() + heapUsed));
  Serial.printf("RAM: setup_heap_delta=%d, arena_reserved=%u, arena_used=%u bytes\n",
                int(setupFreeHeap) - int(free), unsigned(kArenaBytes), unsigned(interpreter->arena_used_bytes()));
}
void setup() {
  Serial.begin(115200);
  delay(1000);
  Serial.println("\nMARVIN / ESP32-WROOM-32 / 16 kHz RIGHT / 1-second windows");
  setupFreeHeap = heap_caps_get_free_size(kHeapCaps);
  const tflite::Model* model = tflite::GetModel(marvin_wider_int8_tflite);
  if (model->version() != TFLITE_SCHEMA_VERSION) fatal("TFLite schema mismatch");
  if (marvin_wider_int8_tflite_len != 17256) fatal("Unexpected model length");
  static tflite::MicroMutableOpResolver<7> resolver;
  if (resolver.AddExpandDims() != kTfLiteOk || resolver.AddConv2D() != kTfLiteOk ||
      resolver.AddReshape() != kTfLiteOk || resolver.AddDepthwiseConv2D() != kTfLiteOk ||
      resolver.AddMean() != kTfLiteOk || resolver.AddFullyConnected() != kTfLiteOk ||
      resolver.AddLogistic() != kTfLiteOk) fatal("Operator registration failed");
  static tflite::MicroInterpreter micro(model, resolver, arena, kArenaBytes);
  interpreter = &micro;
  Serial.printf("Model: %u bytes in flash; tensor arena: %u bytes static\n",
                marvin_wider_int8_tflite_len, unsigned(kArenaBytes));
  Serial.printf("Free heap before AllocateTensors: %u bytes\n", unsigned(heap_caps_get_free_size(kHeapCaps)));
  const TfLiteStatus allocation = interpreter->AllocateTensors();
  Serial.printf("Free heap after AllocateTensors: %u bytes\n", unsigned(heap_caps_get_free_size(kHeapCaps)));
  if (allocation != kTfLiteOk) {
    Serial.printf("AllocateTensors FAILED with %u bytes. Check TFLM diagnostics above; "
                  "if arena exhausted, increase kArenaBytes by 8 KiB and rebuild.\n", unsigned(kArenaBytes));
    fatal("Model allocation failed; inference will not run");
  }
  input = interpreter->input(0);
  output = interpreter->output(0);
  if (!input || !output || input->type != kTfLiteInt8 || output->type != kTfLiteInt8 ||
      input->dims->size != 3 || input->dims->data[0] != 1 || input->dims->data[1] != 98 ||
      input->dims->data[2] != 24 || input->bytes != 2352 || output->dims->size != 2 ||
      output->dims->data[0] != 1 || output->dims->data[1] != 1 || output->bytes != 1)
    fatal("Model tensor type/shape mismatch");
  if (fabsf(input->params.scale - marvin::kInputScale) > 1e-9f || input->params.zero_point != -1 ||
      fabsf(output->params.scale - 0.00390625f) > 1e-9f || output->params.zero_point != -128)
    fatal("Model quantization mismatch");
  for (int i = 0; i < 2; ++i) {
    audio[i] = static_cast<float*>(heap_caps_malloc(marvin::kSamples * sizeof(float), kHeapCaps));
    if (!audio[i]) {
      Serial.printf("Audio allocation failed: buffer=%d, requested=64000, free=%u, largest=%u bytes\n",
          i, unsigned(heap_caps_get_free_size(kHeapCaps)), unsigned(heap_caps_get_largest_free_block(kHeapCaps)));
      fatal("Insufficient contiguous internal RAM for audio");
    }
  }
  frontend.begin();
  freeQueue = xQueueCreateStatic(2, sizeof(int), freeQueueStorage, &freeQueueState);
  readyQueue = xQueueCreateStatic(2, sizeof(AudioWindow), readyQueueStorage, &readyQueueState);
  if (!freeQueue || !readyQueue) fatal("Queue creation failed");
  for (int i = 0; i < 2; ++i) xQueueSend(freeQueue, &i, 0);
  setupI2S();
  TaskHandle_t task = xTaskCreateStaticPinnedToCore(captureTask, "mic_capture", sizeof(captureStack),
      nullptr, 2, captureStack, &captureTaskState, 0);
  if (!task) fatal("Capture task creation failed");
  Serial.printf("Frontend workspace=%u; audio buffers=%u bytes; CPU=%u MHz\n",
                unsigned(sizeof(frontend)), unsigned(2 * marvin::kSamples * sizeof(float)), unsigned(getCpuFrequencyMhz()));
  printRam();
  Serial.println("Speak MARVIN. One result per second when processing keeps up.");
}
void loop() {
  AudioWindow window;
  if (xQueueReceive(readyQueue, &window, pdMS_TO_TICKS(2500)) != pdTRUE) {
    Serial.printf("No valid audio window in 2.5 s; DMA overflows=%u\n", unsigned(readOverflows()));
    return;
  }
  const int64_t preprocessingStart = esp_timer_get_time();
  frontend.compute(audio[window.index], input->data.int8);
  const int64_t preprocessingEnd = esp_timer_get_time();
  // Release audio as soon as features are ready; inference uses the arena only.
  xQueueSend(freeQueue, &window.index, portMAX_DELAY);
  const int64_t inferenceStart = esp_timer_get_time();
  const TfLiteStatus result = interpreter->Invoke();
  const int64_t inferenceEnd = esp_timer_get_time();
  if (result != kTfLiteOk) fatal("Invoke failed");
  const int raw = output->data.int8[0];
  const float probability = (raw - output->params.zero_point) * output->params.scale;
  const int64_t preprocessUs = preprocessingEnd - preprocessingStart;
  const int64_t inferenceUs = inferenceEnd - inferenceStart;
  const int64_t processingUs = inferenceEnd - preprocessingStart;
  const int64_t cycleUs = inferenceEnd - window.startUs;
  static int64_t previousResult = 0;
  const double cadenceMs = previousResult ? (inferenceEnd - previousResult) / 1000.0 : 0;
  previousResult = inferenceEnd;
  Serial.printf("\nWindow %u: raw_int8=%d, probability=%.8f, MARVIN %s (threshold=%.3f)\n",
      unsigned(window.sequence), raw, probability, probability >= kThreshold ? "detected" : "not detected", kThreshold);
  Serial.printf("Timing: preprocessing=%lld us (%.3f ms), inference=%lld us (%.3f ms)\n",
      (long long)preprocessUs, preprocessUs / 1000.0, (long long)inferenceUs, inferenceUs / 1000.0);
  Serial.printf("Timing: capture_wall=%.3f ms, total_cycle_capture_to_result=%.3f ms, processing=%.3f ms\n",
      (window.endUs - window.startUs) / 1000.0, cycleUs / 1000.0, processingUs / 1000.0);
  Serial.printf("Duty: inference/1000ms=%.4f%%, preprocessing+inference/1000ms=%.4f%%; result_interval=%.3f ms\n",
      inferenceUs / 10000.0, processingUs / 10000.0, cadenceMs);
  Serial.printf("Audio: peak=%.6f, skipped_windows=%u, DMA_overflows=%u\n",
      window.peak, unsigned(window.skippedWindows), unsigned(window.dmaOverflows));
  if (processingUs >= 1000000) Serial.println("OVERRUN: processing >= 1 second; cannot sustain 1 Hz.");
  printRam();
  // Capture, not delay(1000), sets the cadence. Serial overhead is included in
  // the next result interval, but excluded from capture-to-result latency.
}
